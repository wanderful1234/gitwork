/*********************************************************************************************
* �ļ�: 28BYJ_48.h
* ����: wangh 2024.02.19
* ˵��: 
* ����: 
* �޸�: 
* ע��: ���߿��Ʋ������
*********************************************************************************************/
#ifndef __28BYJ_48_H__
#define __28BYJ_48_H__
#include "extend.h"

/*********************************************************************************************
* ���Ŷ���
*********************************************************************************************/
#define     M_OUT1_PORT          A
#define     M_OUT2_PORT          A
#define     M_OUT3_PORT          A
#define     M_OUT4_PORT          A

#define     M_OUT1_NUM           7
#define     M_OUT2_NUM           6
#define     M_OUT3_NUM           5
#define     M_OUT4_NUM           4

#define     USE_RTT
// �������ȼ�
#define     STEPMOTOR_PRO        2
// ����������ת����
#define     STEPMOTOR_FORWORD       1
#define     STEPMOTOR_BACKWORD      2
#define     STEPMOTOR_STOP          0
/*********************************************************************************************
* �궨��
*********************************************************************************************/
//ת���õ����� GPIOB
#define     M_OUT1_GPIO          CONS2(GPIO,M_OUT1_PORT)
#define     M_OUT2_GPIO          CONS2(GPIO,M_OUT2_PORT)
#define     M_OUT3_GPIO          CONS2(GPIO,M_OUT3_PORT)
#define     M_OUT4_GPIO          CONS2(GPIO,M_OUT4_PORT)

//ת���õ����� RCC_APB2Periph_GPIOB
#define     M_OUT1_RCC           CONS2(RCC_APB2Periph_GPIO,M_OUT1_PORT)
#define     M_OUT2_RCC           CONS2(RCC_APB2Periph_GPIO,M_OUT2_PORT)
#define     M_OUT3_RCC           CONS2(RCC_APB2Periph_GPIO,M_OUT3_PORT)
#define     M_OUT4_RCC           CONS2(RCC_APB2Periph_GPIO,M_OUT4_PORT)

//ת���õ����� GPIO_Pin_1
#define     M_OUT1_PIN           CONS2(GPIO_Pin_,M_OUT1_NUM)
#define     M_OUT2_PIN           CONS2(GPIO_Pin_,M_OUT2_NUM)
#define     M_OUT3_PIN           CONS2(GPIO_Pin_,M_OUT3_NUM)
#define     M_OUT4_PIN           CONS2(GPIO_Pin_,M_OUT4_NUM)

//ת���õ����� PBout(1)
#define     M_OUT1               CONS3(P,M_OUT1_PORT,out(M_OUT1_NUM))
#define     M_OUT2               CONS3(P,M_OUT2_PORT,out(M_OUT2_NUM))
#define     M_OUT3               CONS3(P,M_OUT3_PORT,out(M_OUT3_NUM))
#define     M_OUT4               CONS3(P,M_OUT4_PORT,out(M_OUT4_NUM))

/*********************************************************************************************
* �ӿں���
*********************************************************************************************/
extern unsigned char stepmotor_mode;
void stepmotor_28byj48_init(void);
void stepmotor_28byj48_loop(void);
#endif