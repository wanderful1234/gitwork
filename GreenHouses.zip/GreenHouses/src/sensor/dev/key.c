/*********************************************************************************************
* �ļ�: key.c
* ����: wangh 2024.02.19
* ˵��: �������Ƴ���
* ����: 
* �޸�: 
* ע��: 
*********************************************************************************************/

/*********************************************************************************************
* ͷ�ļ�
*********************************************************************************************/
#include "key.h"

/*********************************************************************************************
* ����: keyInit()
* ����: ��ʼ������
* ����: ��
* ����: ��
* �޸�: 
* ע��: 
*********************************************************************************************/
void key_init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_APB2PeriphClockCmd(KEY1_RCC, ENABLE);                  //ʹ�ܶ˿�ʱ��
#ifdef KEY2_PIN
  RCC_APB2PeriphClockCmd(KEY2_RCC, ENABLE);                  //ʹ�ܶ˿�ʱ��
#endif
  GPIO_InitStructure.GPIO_Pin = KEY1_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_Mode = KEY1_GPIO_MODE;
  GPIO_Init(KEY1_PORT, &GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin = KEY2_PIN;
  GPIO_InitStructure.GPIO_Mode = KEY2_GPIO_MODE;
  GPIO_Init(KEY2_PORT, &GPIO_InitStructure);
}

/*********************************************************************************************
* ���ƣ�get_key_status
* ���ܣ���ȡ��ǰ����״̬
* ��������
* ���أ�key_status
* �޸ģ�
*********************************************************************************************/
unsigned char get_key_status(void)
{
  char key_status = 0;
  if((GPIO_ReadInputDataBit(KEY1_PORT,KEY1_PIN)) == KEY1_ACT_STATE) 
    key_status |= K1_PREESED;
#ifdef KEY2_PIN
  if((GPIO_ReadInputDataBit(KEY2_PORT,KEY2_PIN)) == KEY2_ACT_STATE)
    key_status |= K2_PREESED;
#endif
#ifdef KEY3_PIN
  if((GPIO_ReadInputDataBit(KEY3_PORT,KEY3_PIN)) == KEY3_ACT_STATE) 
    key_status |= K3_PREESED;
#endif
#ifdef KEY4_PIN
  if((GPIO_ReadInputDataBit(KEY4_PORT,KEY4_PIN)) == KEY4_ACT_STATE)
    key_status |= K4_PREESED;
#endif
  return key_status;                                            //��ȡ��ǰ����״̬
}