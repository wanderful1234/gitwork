/*********************************************************************************************
* �ļ�: TM1638.h
* ����: wangh 2024.02.19
* ˵��: 
* ����: 16���̼�8λ�������ʾģ�� ����ͷ�ļ�
* �޸�: 
* ע��: 
*********************************************************************************************/
#ifndef _TM1638_H
#define _TM1638_H
#include "extend.h"

/*********************************************************************************************
* ���Ŷ���
*********************************************************************************************/
#define     CLK_GPIO          GPIOB
#define     DIO_GPIO          GPIOB
#define     STB_GPIO          GPIOA

#define     CLK_RCC           RCC_APB2Periph_GPIOB
#define     DIO_RCC           RCC_APB2Periph_GPIOB
#define     STB_RCC           RCC_APB2Periph_GPIOA

#define     SCL_PIN           GPIO_Pin_1
#define     DIO_PIN           GPIO_Pin_0
#define     STB_PIN           GPIO_Pin_7
#define     DIO_NUM           0                             //DIO��Ӧ�ı��

#define     CLK               PBout(1)
#define     DIO               PBout(0)
#define     DIO_R             PBin(0)
#define     STB               PAout(7)

#define     DIO_OUT           { if(DIO_NUM<8) \
                                {DIO_GPIO->CRL&=~(u32)0XF<<DIO_NUM*4;DIO_GPIO->CRL|=(u32)3<<DIO_NUM*4;} \
                                else {DIO_GPIO->CRH&=~(u32)0XF<<DIO_NUM*4;DIO_GPIO->CRH|=(u32)3<<DIO_NUM*4;}  \
                              }   //Px(0-15)���ģʽ 
#define     DIO_IN            { if(DIO_NUM<8) \
                                {DIO_GPIO->CRL&=~(u32)0XF<<DIO_NUM*4;DIO_GPIO->CRL|=(u32)8<<DIO_NUM*4;} \
                                else {DIO_GPIO->CRH&=~(u32)0XF<<DIO_NUM*4;DIO_GPIO->CRH|=(u32)8<<DIO_NUM*4;}  \
                              }   //Px(0-15)����ģʽ

/*********************************************************************************************
* �궨��
*********************************************************************************************/
#define segA 0x40
#define segB 0x20
#define segC 0x10
#define segD 0x08
#define segE 0x04
#define segF 0x02
#define segG 0x01
#define segDP 0x80

#define ndp0 (segA+segB+segC+segD+segE+segF)
#define ndp1 (segB+segC)
#define ndp2 (segA+segB+segG+segE+segD)
#define ndp3 (segA+segB+segG+segC+segD)
#define ndp4 (segF+segG+segB+segC)
#define ndp5 (segA+segF+segG+segC+segD)
#define ndp6 (segA+segF+segG+segC+segD+segE)
#define ndp7 (segA+segB+segC)
#define ndp8 (segA+segB+segC+segD+segE+segF+segG)
#define ndp9 (segA+segB+segC+segD+segF+segG)
#define ndpA (segA+segB+segC+segE+segF+segG)
#define ndpB (segC+segD+segE+segF+segG)
#define ndpC (segA+segD+segE+segF)
#define ndpD (segB+segC+segD+segE+segG)
#define ndpE (segA+segD+segE+segF+segG)
#define ndpF (segA+segE+segF+segG)
#define wdp0 (segA+segB+segC+segD+segE+segF+segDP)
#define wdp1 (segB+segC+segDP)
#define wdp2 (segA+segB+segG+segE+segD+segDP)
#define wdp3 (segA+segB+segG+segC+segD+segDP)
#define wdp4 (segF+segG+segB+segC+segDP)
#define wdp5 (segA+segF+segG+segC+segD+segDP)
#define wdp6 (segA+segF+segG+segC+segD+segE+segDP)
#define wdp7 (segA+segB+segC+segDP)
#define wdp8 (segA+segB+segC+segD+segE+segF+segG+segDP)
#define wdp9 (segA+segB+segC+segD+segF+segG+segDP)
#define wdpA (segA+segB+segC+segE+segF+segG+segDP)
#define wdpB (segC+segD+segE+segF+segG+segDP)
#define wdpC (segA+segD+segE+segF+segDP)
#define wdpD (segB+segC+segD+segE+segG+segDP)
#define wdpE (segA+segD+segE+segF+segG+segDP)
#define wdpF (segA+segE+segF+segG+segDP)

/*********************************************************************************************
* �ⲿ�ӿں���
*********************************************************************************************/
void TM1638_Write(unsigned char	DATA);
unsigned char TM1638_Read(void);
unsigned char Read_key(void);
void Write_COM(unsigned char cmd);
void Write_DATA(unsigned char add,unsigned char DATA);
void TM1638_init(void);
void LedDisplay(unsigned char ddata0,unsigned char ddata1,unsigned char ddata2,unsigned char ddata3,
               unsigned char ddata4,unsigned char ddata5,unsigned char ddata6,unsigned char ddata7);

#endif
