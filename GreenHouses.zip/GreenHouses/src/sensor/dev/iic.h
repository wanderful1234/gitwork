/*********************************************************************************************
* �ļ���iic.h
* ���ߣ�wangh 2024.2.21
* ˵����iicͷ�ļ�
* �޸ģ�
* ע�ͣ�F1ϵ�е�IIC����ͨ�ú���
*********************************************************************************************/
#ifndef __IIC_H__
#define __IIC_H__

/*********************************************************************************************
* ͷ�ļ�
*********************************************************************************************/
#include <rtthread.h>
#include "stm32f10x.h"
#include "board.h"
#include <math.h>
#include <stdio.h>

/*********************************************************************************************
* ���Ŷ���
*********************************************************************************************/
// PB1 SCL PB0 SDA
#define     I2C_CLK_GPIO          GPIOB
#define     I2C_SDA_GPIO          GPIOB
#define     I2C_CLK_RCC           RCC_APB2Periph_GPIOB
#define     I2C_SDA_RCC           RCC_APB2Periph_GPIOB
#define     I2C_SCL_PIN           GPIO_Pin_1
#define     I2C_SDA_PIN           GPIO_Pin_0
#define     SDA_NUM               0                             //SDA��Ӧ�ı��
#define     I2C_SPEED_DELAY       2                             //I2C�������ٶȣ�����ʱ����

/*********************************************************************************************
* �궨��
*********************************************************************************************/
/* λ�� */
#define     IIC_SCL               PBout(1) //SCL
#define     IIC_SDA               PBout(0) //SDA 
#define     READ_SDA              PBin(0)  //����SDA 
/* F1ϵ�п⺯�� */
#define     SCL(x)                {if(x)GPIO_WriteBit(I2C_CLK_GPIO,I2C_SCL_PIN,Bit_SET);else GPIO_WriteBit(I2C_CLK_GPIO,I2C_SCL_PIN,Bit_RESET);}
#define     SDA(x)                {if(x)GPIO_WriteBit(I2C_SDA_GPIO,I2C_SDA_PIN,Bit_SET);else GPIO_WriteBit(I2C_SDA_GPIO,I2C_SDA_PIN,Bit_RESET);}
#define     R_SDA                 GPIO_ReadInputDataBit(I2C_SDA_GPIO,I2C_SDA_PIN)
#define     SDA_OUT               { if(SDA_NUM<8) \
                                    {I2C_SDA_GPIO->CRL&=~(u32)0XF<<SDA_NUM*4;I2C_SDA_GPIO->CRL|=(u32)3<<SDA_NUM*4;} \
                                    else {I2C_SDA_GPIO->CRH&=~(u32)0XF<<SDA_NUM*4;I2C_SDA_GPIO->CRH|=(u32)3<<SDA_NUM*4;}  \
                                  }   //Px(0-15)���ģʽ 
#define     SDA_IN                { if(SDA_NUM<8) \
                                    {I2C_SDA_GPIO->CRL&=~(u32)0XF<<SDA_NUM*4;I2C_SDA_GPIO->CRL|=(u32)8<<SDA_NUM*4;} \
                                    else {I2C_SDA_GPIO->CRH&=~(u32)0XF<<SDA_NUM*4;I2C_SDA_GPIO->CRH|=(u32)8<<SDA_NUM*4;}  \
                                  }   //Px(0-15)����ģʽ

/*********************************************************************************************
* �ⲿԭ�ͺ���
*********************************************************************************************/
void iic_init(void);
void iic_start(void);
void iic_stop(void);
void iic_send_ack(char ack);
int iic_waitack(void);
/* �����в�����Ӧ�� */
void iic_write_byte(unsigned char SendByte);
unsigned char iic_read_byte(void);
/* �����а���Ӧ�� */
unsigned char iic_write_byte_ack(unsigned char data);
unsigned char iic_read_byte_ack(unsigned char ack);
unsigned char iic_read_byte_ack_Ex(unsigned char ack);

int8_t iic_write(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len);
int8_t iic_read(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len);

void delay(unsigned int t);
#endif
